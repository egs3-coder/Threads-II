# Justificativa: US07, Análise Preditiva de Demanda por Tipo Sanguíneo

## 1. Como a operação foi escolhida

Seguimos o roteiro da atividade: listamos as operações da camada de aplicação do HemoTrack e, para cada uma, perguntamos onde o tempo é gasto na escala nacional, qual a Big-O e se os dados podem ser partidos em fatias independentes.

| História | O que faz | Onde está o tempo | Big-O | Particionável? | Serve? |
|---|---|---|---|---|---|
| US01 Requisição | grava 1 pedido | banco (INSERT) | O(1) | não há volume | Não |
| US02 Entrada de bolsa | grava 1 bolsa | banco (INSERT) | O(1) | não há volume | Não |
| US03 Alocação FEFO | busca bolsa compatível que vence antes | consulta com índice (tipo, validade) | O(log n) | não: requisições disputam o mesmo estoque | Não |
| US04 Rota (Dijkstra) | menor caminho até 1 hospital | CPU, mas em um grafo pequeno | O((V+E) log V) | só em lote de muitas rotas | Candidata fraca |
| US05 Telemetria | recebe leituras de sensores | rede, eventos simultâneos | O(1) por leitura | é concorrência, não volume | Não |
| US06 Painel gerencial | contagens e médias | um `GROUP BY` bem indexado resolve | O(n) no banco | sim | Não: a resposta certa é melhorar o SQL |
| **US07 Demanda preditiva** | **série semanal por tipo + estatística** | **CPU, sobre milhões de registros** | **O(n)** | **sim** | **Sim** |

## 2. A operação escolhida

A US07 pede que o analista veja, para cada tipo sanguíneo (A, B, AB, O, Rh+/−), a média estimada de consumo (μ), a dispersão (σ) e os tipos com probabilidade de ruptura de estoque. O endpoint `GET /api/demanda/preditiva` faz isso em quatro etapas:

1. **Percorre todo o histórico** de requisições das últimas 104 semanas (2 anos). Para cada uma: descarta as canceladas, converte o instante gravado em UTC para a **data local do hospital** (o Brasil tem 4 fusos; uma requisição às 23h em Manaus já é outro dia em UTC) e encontra a **semana epidemiológica** correspondente.
2. **Soma as bolsas** na célula `[tipo sanguíneo][semana]` (8 × 104 = 832 células).
3. Com as 8 séries semanais prontas, calcula **μ, σ, a tendência** (regressão linear) e a **projeção das próximas 13 semanas**.
4. Compara a projeção com o estoque atual e calcula **P(ruptura) = 1 − Φ((estoque − demanda) / σ√13)**, destacando os tipos em alerta (no nosso cenário, O−).

## 3. Big-O da solução sequencial

Sejam **n** o número de requisições, **t = 8** tipos e **w = 104** semanas.

- Etapa 1 e 2: cada registro é visitado uma vez com trabalho constante → **O(n)**.
- Etapas 3 e 4: percorrem as séries → **O(t · w)** = O(832), constante em relação a n.
- **Total: O(n + t·w) = O(n)**. Memória extra: O(t·w).

Medimos o custo por registro: cerca de **49 ns** e ele se mantém constante de 1 a 10 milhões de registros (≈ 49 ms para 1 milhão, ≈ 494 ms para 10 milhões), exatamente o crescimento linear previsto.

## 4. Onde está o gargalo (e por que não é "melhorar o SQL")

Na escala nacional o histórico chega a dezenas de milhões de requisições, e o painel preditivo é consultado o dia inteiro, com o analista mudando parâmetros. Por isso a base é lida do banco **uma vez** para um snapshot em memória na camada de aplicação (atualizado periodicamente), e cada requisição ao endpoint trabalha sobre esse snapshot:

- **O tempo medido no endpoint não tem espera de banco nem de rede interna**: é 100% laço sobre os registros. Com 10 milhões de registros são ~0,5 s de CPU em uma única thread, a cada consulta.
- O trabalho por registro é **computação**, não I/O: conversão de fuso com as regras de cada zona, cálculo da semana e acumulação.
- O banco transacional está ocupado com o caminho crítico (requisições emergenciais da US01, entradas da US02, telemetria da US05). Rodar varreduras analíticas pesadas nele o dia inteiro competiria com essas escritas; a estatística e o modelo de projeção vivem na aplicação.

Ou seja: mesmo com a melhor consulta SQL possível, depois que os dados estão na aplicação ainda sobra O(n) de cálculo, e é esse cálculo que cresce com o país.

## 5. Por que os dados são particionáveis

- **Cada registro contribui para uma única célula e não depende de nenhum outro.** O resultado do registro 7 não muda o do registro 8.
- **A operação de agregação é a soma de inteiros (`long`)**, que é associativa e comutativa. Então dá para dividir os n registros em p fatias, somar cada fatia separadamente e depois somar os p resultados parciais: o total é o mesmo, em qualquer ordem.
- **A lista é somente leitura** durante o processamento: as threads a compartilham sem precisar de trava.
- **Cada thread tem o seu próprio acumulador** `long[8][104]`. Não há escrita compartilhada no laço, logo não há race condition. A redução final soma p × 832 números, custo desprezível.

Esse é o padrão **dividir → mapear → reduzir**:

```
          ┌── fatia 1 (n/p registros) ─► thread 1 ─► acumulador 1 ──┐
histórico ├── fatia 2 ──────────────────► thread 2 ─► acumulador 2 ──┼─► soma ─► μ, σ, tendência, P(ruptura)
          └── fatia p ──────────────────► thread p ─► acumulador p ──┘
```

**Complexidade da versão paralela:** trabalho total O(n + p·t·w); tempo O(n/p + p·t·w). A Big-O do trabalho continua O(n); o que muda é que ele é dividido entre p núcleos.

**Como garantimos a mesma resposta:** o resultado inclui uma assinatura SHA-256 de todos os números agregados. Os testes (`ProcessadorDemandaTest`) e o endpoint `/api/demanda/verificar` confirmam que sequencial, 2, 4, 8 threads de plataforma e threads virtuais produzem a mesma assinatura. A versão `modo=inseguro` (todas as threads no mesmo acumulador, sem sincronização) existe só para mostrar a race condition que evitamos.
