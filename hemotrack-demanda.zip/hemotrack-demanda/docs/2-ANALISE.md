# Medições e análise

> Preencham os campos entre colchetes com os números da bateria (página, passo 3, botão "Copiar tabela em Markdown").
> O texto da análise já explica o comportamento esperado; confiram se os números de vocês confirmam cada frase e ajustem onde não confirmarem.

## Máquina de teste

Processador: [modelo], [N] núcleos físicos / [N] lógicos · RAM: [X] GB · Java [21.x] · heap `-Xmx3g`
(os dados aparecem no topo da página, vindos de `GET /api/sistema`)

## Tabela (mediana de [10] repetições, tempo de resposta do endpoint)

| Registros | Versão | Threads | Resposta (ms) | Processamento (ms) | Speedup | Eficiência |
|---:|:---|---:|---:|---:|---:|---:|
| 100.000 | sequencial | 1 | | | 1,00× | 100% |
| 100.000 | plataforma | 2 | | | | |
| 100.000 | plataforma | 4 | | | | |
| 100.000 | plataforma | 8 | | | | |
| 1.000.000 | sequencial | 1 | | | 1,00× | 100% |
| 1.000.000 | plataforma | 2 | | | | |
| 1.000.000 | plataforma | 4 | | | | |
| 1.000.000 | plataforma | 8 | | | | |
| 1.000.000 | virtual | 8 | | | | |

Speedup = T(sequencial) ÷ T(p threads). Eficiência = speedup ÷ p.
Gráficos: exportem os dois gráficos da página (tempo × threads e speedup × threads com a reta ideal).

## Análise

**O ganho foi linear?** Não. Com 1 milhão de registros o speedup foi de [S2]× com 2 threads, [S4]× com 4 e [S8]× com 8, abaixo do ideal (2, 4, 8). A Lei de Amdahl explica parte: há trechos que não se dividem (receber a requisição HTTP, gerar o JSON, somar os parciais e calcular μ, σ e a projeção). O restante vem do hardware: a partir de [N físicos] threads elas passam a disputar os mesmos núcleos (hyper-threading não dobra a capacidade), a largura de banda da memória é compartilhada, pois os registros precisam vir da RAM, e há o custo de despachar tarefas e esperar a mais lenta terminar (a linha do tempo mostra fatias terminando em momentos diferentes). Com 100 mil registros o ganho é pequeno ou nulo: o processamento dura poucos milissegundos e o custo fixo do endpoint domina. O paralelismo compensa quando n é grande.

**A Big-O mudou?** Não. O trabalho total continua O(n); cada registro é visitado uma única vez. O que muda é o tempo decorrido: O(n/p + p·t·w), porque o trabalho é repartido entre p núcleos e a redução soma p acumuladores de 832 células. Threads mudam a constante, não a classe de complexidade. Dobrar a base continua dobrando o tempo, com qualquer número de threads, e as medições de [1 mi] para [5 mi] e [10 mi] confirmam isso.

**Concorrência × paralelismo.** Na Mesa DJ as threads atendiam eventos simultâneos e independentes (várias pessoas pedindo músicas ao mesmo tempo): isso é concorrência, lidar com muitas tarefas que chegam juntas, cujo objetivo é não bloquear ninguém, e funciona até com um único núcleo, alternando entre as tarefas. Aqui existe uma única tarefa grande, e as threads a dividem em pedaços que rodam no mesmo instante em núcleos diferentes: isso é paralelismo, cujo objetivo é terminar mais rápido e que exige vários núcleos. Comprovamos isso num ambiente com um único núcleo: 4 threads levaram o mesmo tempo que a versão sequencial (≈49 ms para 1 milhão), porque só se revezavam. Havia concorrência, mas não paralelismo. As threads virtuais do Java 21 confirmam a diferença: ficaram [iguais/próximas] às de plataforma, porque elas foram feitas para concorrência massiva com espera de I/O (milhares de requisições bloqueadas em banco ou rede); em trabalho de CPU puro elas rodam sobre o mesmo número de núcleos e não trazem ganho.

**Quando nem 8 threads bastarem.** O limite passa a ser uma máquina só: núcleos e memória de um servidor. O próximo passo é escalar horizontalmente com o mesmo padrão dividir → mapear → reduzir, só que entre máquinas. Várias instâncias do serviço atrás de um balanceador de carga; o histórico particionado (sharding) por região ou por estado, com cada nó calculando os seus parciais e um agregador somando, exatamente como fizemos com os acumuladores das threads. Também dá para deixar de recalcular tudo a cada consulta: manter os agregados semanais atualizados de forma incremental por eventos (uma fila recebe cada nova requisição e soma na célula certa) e servir o painel a partir de um modelo de leitura com cache (CQRS). Para volumes ainda maiores, motores de processamento distribuído como Spark fazem esse map-reduce entre dezenas de nós. É a passagem de sistema em camadas para sistema distribuído, o assunto da Unidade 2.
