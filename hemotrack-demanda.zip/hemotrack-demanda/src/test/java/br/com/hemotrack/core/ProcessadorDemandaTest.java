package br.com.hemotrack.core;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

/** Requisito da atividade: sequencial e paralela devem devolver EXATAMENTE a mesma resposta. */
class ProcessadorDemandaTest {

    static BaseHistorica base;
    static ProcessadorDemanda processador;
    static ResultadoDemanda referencia;

    @BeforeAll
    static void preparar() {
        base = GeradorDados.gerar(300_000, 42);
        processador = new ProcessadorDemanda();
        referencia = processador.sequencial(base).resultado();
    }

    @AfterAll
    static void encerrar() { processador.close(); }

    @ParameterizedTest
    @ValueSource(ints = {2, 3, 4, 7, 8, 16})
    void threadsDePlataformaDevolvemOMesmoResultado(int threads) {
        assertEquals(referencia, processador.plataforma(base, threads).resultado());
    }

    @ParameterizedTest
    @ValueSource(ints = {2, 4, 8})
    void threadsVirtuaisDevolvemOMesmoResultado(int threads) {
        assertEquals(referencia, processador.virtual(base, threads).resultado());
    }

    @Test
    void todasAsFatiasCobremABaseSemSobreposicao() {
        var fatias = processador.plataforma(base, 8).fatias();
        assertEquals(0, fatias.get(0).inicioIndice());
        for (int i = 1; i < fatias.size(); i++) {
            assertEquals(fatias.get(i - 1).fimIndice(), fatias.get(i).inicioIndice());
        }
        assertEquals(base.tamanho(), fatias.get(fatias.size() - 1).fimIndice());
    }

    @Test
    void contagemFechaComOTamanhoDaBase() {
        assertEquals(base.tamanho(),
                referencia.registrosValidos() + referencia.registrosCancelados() + referencia.foraDaJanela());
    }

    @Test
    void oNegativoApareceEmAlerta() {
        assertTrue(referencia.tiposEmAlerta().contains("O-"));
    }
}
