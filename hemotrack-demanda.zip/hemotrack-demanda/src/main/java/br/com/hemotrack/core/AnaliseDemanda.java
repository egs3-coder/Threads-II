package br.com.hemotrack.core;

import java.util.ArrayList;
import java.util.List;

/**
 * Etapa final (sequencial) da US07: a partir das séries semanais já agregadas,
 * calcula μ, σ, tendência, projeção trimestral e probabilidade de ruptura.
 *
 * Custo: O(tipos × semanas) = O(8 × 104). Não depende do número de registros,
 * por isso não compensa paralelizar — é a "parte serial" da Lei de Amdahl.
 */
public final class AnaliseDemanda {

    public static final int SEMANAS_PROJECAO = 13; // próximo trimestre

    private AnaliseDemanda() { }

    public static ResultadoDemanda analisar(Acumulador total, long[] estoqueAtual) {
        int w = total.semanas();
        List<ProjecaoTipo> projecoes = new ArrayList<>();
        List<String> alertas = new ArrayList<>();

        double tMedio = (w - 1) / 2.0;
        double somaQuadT = 0;
        for (int t = 0; t < w; t++) somaQuadT += (t - tMedio) * (t - tMedio);

        for (TipoSanguineo tipo : TipoSanguineo.TODOS) {
            long[] x = total.serie(tipo);

            long soma = 0;
            for (long v : x) soma += v;
            double media = (double) soma / w;

            double somaQuad = 0, cov = 0;
            for (int t = 0; t < w; t++) {
                double d = x[t] - media;
                somaQuad += d * d;
                cov += (t - tMedio) * d;
            }
            double desvio = Math.sqrt(somaQuad / (w - 1));
            double inclinacao = cov / somaQuadT;

            double projecao = 0;
            for (int t = w; t < w + SEMANAS_PROJECAO; t++) {
                projecao += Math.max(0, media + inclinacao * (t - tMedio));
            }
            double desvioTrimestre = desvio * Math.sqrt(SEMANAS_PROJECAO);

            long estoque = estoqueAtual[tipo.ordinal()];
            double z = desvioTrimestre == 0 ? Double.POSITIVE_INFINITY : (estoque - projecao) / desvioTrimestre;
            double pRuptura = 1.0 - phi(z);
            String risco = pRuptura >= 0.5 ? "ALTO" : pRuptura >= 0.2 ? "MODERADO" : "BAIXO";
            if (!"BAIXO".equals(risco)) alertas.add(tipo.rotulo());

            projecoes.add(new ProjecaoTipo(tipo.rotulo(), soma,
                    arred(media), arred(desvio), arred(inclinacao),
                    arred(projecao), arred(desvioTrimestre),
                    estoque, arred(pRuptura), risco));
        }

        return new ResultadoDemanda(total.registrosValidos(), total.registrosCancelados(), total.foraDaJanela(),
                total.totalBolsas(), w, projecoes, alertas, total.assinatura());
    }

    /** Função de distribuição acumulada da Normal padrão. */
    static double phi(double z) {
        if (Double.isInfinite(z)) return z > 0 ? 1.0 : 0.0;
        return 0.5 * (1.0 + erf(z / Math.sqrt(2.0)));
    }

    /** Aproximação de Abramowitz & Stegun 7.1.26 (erro < 1,5e-7). */
    private static double erf(double x) {
        double sinal = Math.signum(x);
        x = Math.abs(x);
        double t = 1.0 / (1.0 + 0.3275911 * x);
        double y = 1.0 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t
                - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x);
        return sinal * y;
    }

    private static double arred(double v) {
        return Math.round(v * 10_000.0) / 10_000.0;
    }
}
