package br.com.hemotrack.core;

import java.util.List;

/** Resposta de negócio: idêntica em todas as versões (sequencial, 2, 4, 8 threads, virtuais). */
public record ResultadoDemanda(long registrosValidos,
                               long registrosCancelados,
                               long foraDaJanela,
                               long totalBolsas,
                               int semanasAnalisadas,
                               List<ProjecaoTipo> projecoes,
                               List<String> tiposEmAlerta,
                               String assinatura) {
}
