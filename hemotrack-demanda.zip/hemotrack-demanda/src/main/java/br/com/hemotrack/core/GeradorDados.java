package br.com.hemotrack.core;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.SplittableRandom;

/**
 * Gera um histórico sintético e determinístico (mesma semente = mesmos dados):
 * 104 semanas epidemiológicas (2 anos) de requisições de todo o país.
 */
public final class GeradorDados {

    public static final int SEMANAS = 104;
    public static final int DIAS = SEMANAS * 7;
    public static final int HOSPITAIS = 5_000;
    /** Semana epidemiológica começa no domingo. Data fixa para o resultado ser reprodutível. */
    public static final LocalDate INICIO = LocalDate.of(2024, 9, 15).with(TemporalAdjusters.previousOrSame(DayOfWeek.SUNDAY));

    private static final long MS_DIA = 86_400_000L;

    /** Fator estoque / demanda esperada no trimestre. Abaixo de 1 = risco de ruptura. */
    private static final double[] FATOR_ESTOQUE = {
            1.45, // A+
            1.35, // A-
            1.40, // B+
            1.20, // B-
            1.30, // AB+
            1.00, // AB-  (no limite)
            1.40, // O+
            0.95  // O-   (doador universal com demanda crescente: o caso crítico)
    };

    private GeradorDados() { }

    public static BaseHistorica gerar(int quantidade, long semente) {
        long t0 = System.nanoTime();
        SplittableRandom rnd = new SplittableRandom(semente);

        double[] acumTipo = acumulada(TipoSanguineo.TODOS.length, i -> TipoSanguineo.TODOS[i].prevalencia());
        double[] acumFuso = acumulada(FusosBrasil.PESO.length, i -> FusosBrasil.PESO[i]);

        // fuso fixo por hospital
        byte[] fusoDoHospital = new byte[HOSPITAIS + 1];
        for (int h = 1; h <= HOSPITAIS; h++) fusoDoHospital[h] = (byte) sortear(rnd.nextDouble(), acumFuso);

        long inicioUtcMs = INICIO.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli();

        List<RegistroConsumo> lista = new ArrayList<>(quantidade);
        for (int i = 0; i < quantidade; i++) {
            TipoSanguineo tipo = TipoSanguineo.TODOS[sortear(rnd.nextDouble(), acumTipo)];

            // O- tem demanda crescente: o máximo de dois sorteios concentra registros no fim do período
            int dia = rnd.nextInt(DIAS);
            if (tipo == TipoSanguineo.O_NEG) dia = Math.max(dia, rnd.nextInt(DIAS));

            int bolsas = 1 + rnd.nextInt(3);
            int semanaDoAno = (dia / 7) % 52;
            boolean altaTemporada = semanaDoAno >= 13 && semanaDoAno <= 17   // fim de ano
                    || semanaDoAno >= 22 && semanaDoAno <= 25;               // carnaval
            if (altaTemporada && rnd.nextDouble() < 0.35) bolsas++;

            int hospital = 1 + rnd.nextInt(HOSPITAIS);
            long instante = inicioUtcMs + dia * MS_DIA + rnd.nextLong(MS_DIA); // gravado em UTC
            boolean atendida = rnd.nextDouble() >= 0.05;                        // 5% canceladas

            lista.add(new RegistroConsumo(i + 1L, hospital, fusoDoHospital[hospital], tipo, instante, bolsas, atendida));
        }

        // Estoque atual proporcional à demanda esperada de um trimestre (13 semanas)
        double mediaBolsas = 2.0 + 0.35 * (9.0 / 52.0);
        long[] estoque = new long[TipoSanguineo.QUANTIDADE];
        for (TipoSanguineo t : TipoSanguineo.TODOS) {
            double esperado = quantidade * t.prevalencia() * 0.95 * mediaBolsas * 13.0 / SEMANAS;
            estoque[t.ordinal()] = Math.round(esperado * FATOR_ESTOQUE[t.ordinal()]);
        }

        double ms = (System.nanoTime() - t0) / 1e6;
        return new BaseHistorica(Collections.unmodifiableList(lista), INICIO, SEMANAS, estoque, semente, ms);
    }

    private static double[] acumulada(int n, java.util.function.IntToDoubleFunction peso) {
        double[] a = new double[n];
        double soma = 0;
        for (int i = 0; i < n; i++) a[i] = soma += peso.applyAsDouble(i);
        for (int i = 0; i < n; i++) a[i] /= soma;
        return a;
    }

    private static int sortear(double valor, double[] acumulada) {
        for (int i = 0; i < acumulada.length; i++) if (valor < acumulada[i]) return i;
        return acumulada.length - 1;
    }
}
