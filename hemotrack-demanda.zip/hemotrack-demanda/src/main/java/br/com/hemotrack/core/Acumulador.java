package br.com.hemotrack.core;

import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.time.LocalDate;
import java.util.HexFormat;
import java.util.List;

/**
 * Resultado parcial da agregação: bolsas consumidas por (tipo sanguíneo × semana epidemiológica).
 *
 * Cada thread tem o SEU acumulador (nada compartilhado durante o laço) e no fim
 * os parciais são somados. Como tudo é inteiro (long), a soma é associativa e
 * comutativa: a ordem da agregação não muda o resultado, e a versão paralela
 * devolve exatamente o mesmo que a sequencial.
 */
public final class Acumulador {

    final long[][] bolsas;          // [tipo][semana]
    long registrosValidos;
    long registrosCancelados;
    long foraDaJanela;
    private final int semanas;
    private final long inicioEpochDay;

    public Acumulador(int semanas, LocalDate inicio) {
        this.semanas = semanas;
        this.inicioEpochDay = inicio.toEpochDay();
        this.bolsas = new long[TipoSanguineo.QUANTIDADE][semanas];
    }

    /**
     * O laço quente do algoritmo: O(k) para uma fatia de k registros.
     * Para cada requisição: descarta canceladas, converte o instante UTC para a data
     * LOCAL do hospital (4 fusos no Brasil), descobre a semana epidemiológica e soma as bolsas.
     */
    public void processar(List<RegistroConsumo> registros, int inicio, int fim) {
        for (int i = inicio; i < fim; i++) {
            RegistroConsumo r = registros.get(i);
            if (!r.atendida()) {
                registrosCancelados++;
                continue;
            }
            LocalDate dataLocal = Instant.ofEpochMilli(r.instanteUtcMs())
                    .atZone(FusosBrasil.ZONAS[r.fuso()])
                    .toLocalDate();
            long semana = Math.floorDiv(dataLocal.toEpochDay() - inicioEpochDay, 7);
            if (semana < 0 || semana >= semanas) {
                foraDaJanela++;
                continue;
            }
            bolsas[r.tipo().ordinal()][(int) semana] += r.bolsas();
            registrosValidos++;
        }
    }

    /** Redução de um parcial neste acumulador: O(tipos × semanas) = O(832). */
    public void somar(Acumulador outro) {
        for (int t = 0; t < bolsas.length; t++) {
            long[] destino = bolsas[t];
            long[] origem = outro.bolsas[t];
            for (int s = 0; s < semanas; s++) destino[s] += origem[s];
        }
        registrosValidos += outro.registrosValidos;
        registrosCancelados += outro.registrosCancelados;
        foraDaJanela += outro.foraDaJanela;
    }

    public long[] serie(TipoSanguineo tipo) { return bolsas[tipo.ordinal()]; }
    public long registrosValidos() { return registrosValidos; }
    public long registrosCancelados() { return registrosCancelados; }
    public long foraDaJanela() { return foraDaJanela; }
    public int semanas() { return semanas; }

    public long totalBolsas() {
        long total = 0;
        for (long[] serie : bolsas) for (long v : serie) total += v;
        return total;
    }

    /** SHA-256 de todos os números agregados: prova objetiva de que duas versões deram o mesmo resultado. */
    public String assinatura() {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            ByteBuffer buf = ByteBuffer.allocate(8);
            for (long[] serie : bolsas) for (long v : serie) md.update(buf.clear().putLong(v).array());
            md.update(buf.clear().putLong(registrosValidos).array());
            md.update(buf.clear().putLong(registrosCancelados).array());
            md.update(buf.clear().putLong(foraDaJanela).array());
            return HexFormat.of().formatHex(md.digest()).substring(0, 16);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
