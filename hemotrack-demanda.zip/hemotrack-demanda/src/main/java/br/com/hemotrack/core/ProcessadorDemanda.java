package br.com.hemotrack.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * US07 - Análise Preditiva de Demanda.
 *
 * Estratégia paralela (particionamento + redução, o padrão "map-reduce" dentro de uma JVM):
 *   1. DIVIDIR  a lista de n registros em p fatias contíguas e independentes;
 *   2. MAPEAR   cada fatia em uma thread, com um Acumulador LOCAL (sem estado compartilhado);
 *   3. REDUZIR  os p acumuladores parciais em um total;
 *   4. ANALISAR o total (μ, σ, tendência, ruptura) - etapa sequencial e barata.
 *
 * Complexidade:
 *   sequencial: tempo O(n)
 *   paralela  : trabalho total O(n + p·k); tempo O(n/p + p·k), com k = tipos × semanas = 832
 */
public final class ProcessadorDemanda implements AutoCloseable {

    /** Pools reaproveitados entre requisições: criar threads a cada chamada custaria caro. */
    private final Map<Integer, ExecutorService> pools = new ConcurrentHashMap<>();

    // ------------------------------------------------------------------ SEQUENCIAL

    public Execucao sequencial(BaseHistorica base) {
        long t0 = System.nanoTime();
        Acumulador total = new Acumulador(base.semanas(), base.inicio());
        total.processar(base.registros(), 0, base.tamanho());
        long t1 = System.nanoTime();

        List<FatiaExecutada> linha = List.of(new FatiaExecutada(0, Thread.currentThread().getName(),
                false, 0, base.tamanho(), 0, ms(t1 - t0)));

        long t2 = System.nanoTime(); // não há agregação na versão sequencial
        ResultadoDemanda resultado = AnaliseDemanda.analisar(total, base.estoqueAtual());
        long t3 = System.nanoTime();

        return new Execucao("sequencial", 1, base.tamanho(), ms(t3 - t0),
                ms(t1 - t0), ms(t2 - t1), ms(t3 - t2), linha, resultado);
    }

    // ------------------------------------------------------------------ THREADS DE PLATAFORMA

    public Execucao plataforma(BaseHistorica base, int threads) {
        return paralelo("plataforma", base, threads, pool(threads));
    }

    // ------------------------------------------------------------------ THREADS VIRTUAIS (Java 21)

    public Execucao virtual(BaseHistorica base, int threads) {
        ThreadFactory fabrica = Thread.ofVirtual().name("hemo-virtual-", 1).factory();
        try (ExecutorService executor = Executors.newThreadPerTaskExecutor(fabrica)) {
            return paralelo("virtual", base, threads, executor);
        }
    }

    // ------------------------------------------------------------------ NÚCLEO PARALELO (seguro)

    private Execucao paralelo(String modo, BaseHistorica base, int p, ExecutorService executor) {
        validarThreads(p);
        long t0 = System.nanoTime();
        int n = base.tamanho();

        // 1. DIVIDIR: p tarefas, cada uma com a SUA fatia e o SEU acumulador
        List<Callable<Parcial>> tarefas = new ArrayList<>(p);
        for (int i = 0; i < p; i++) {
            final int indice = i;
            final int inicio = (int) ((long) n * i / p);
            final int fim = (int) ((long) n * (i + 1) / p);
            tarefas.add(() -> {
                long ini = System.nanoTime();
                Acumulador local = new Acumulador(base.semanas(), base.inicio());
                local.processar(base.registros(), inicio, fim);      // 2. MAPEAR
                long fimNs = System.nanoTime();
                Thread atual = Thread.currentThread();
                return new Parcial(local, new FatiaExecutada(indice, nomeThread(atual), atual.isVirtual(),
                        inicio, fim, ms(ini - t0), ms(fimNs - t0)));
            });
        }

        List<Parcial> parciais = executarTodas(executor, tarefas);
        long t1 = System.nanoTime();

        // 3. REDUZIR: sempre na mesma ordem (fatia 0, 1, 2...) - determinístico
        Acumulador total = new Acumulador(base.semanas(), base.inicio());
        List<FatiaExecutada> linha = new ArrayList<>(p);
        for (Parcial parcial : parciais) {
            total.somar(parcial.acumulador());
            linha.add(parcial.fatia());
        }
        long t2 = System.nanoTime();

        // 4. ANALISAR
        ResultadoDemanda resultado = AnaliseDemanda.analisar(total, base.estoqueAtual());
        long t3 = System.nanoTime();

        return new Execucao(modo, p, n, ms(t3 - t0), ms(t1 - t0), ms(t2 - t1), ms(t3 - t2), linha, resultado);
    }

    // ------------------------------------------------------------------ VERSÃO ERRADA (didática)

    /**
     * NÃO USAR EM PRODUÇÃO. Todas as threads escrevem no MESMO acumulador sem sincronização.
     * "x += y" não é atômico (ler, somar, gravar): duas threads leem o mesmo valor,
     * cada uma soma a sua parte e uma gravação sobrescreve a outra -> atualizações perdidas.
     * Existe só para demonstrar a race condition que a atividade pede para evitar.
     */
    public Execucao inseguro(BaseHistorica base, int p) {
        validarThreads(p);
        long t0 = System.nanoTime();
        int n = base.tamanho();
        Acumulador compartilhado = new Acumulador(base.semanas(), base.inicio());
        List<Callable<Parcial>> tarefas = new ArrayList<>(p);
        for (int i = 0; i < p; i++) {
            final int indice = i;
            final int inicio = (int) ((long) n * i / p);
            final int fim = (int) ((long) n * (i + 1) / p);
            tarefas.add(() -> {
                long ini = System.nanoTime();
                compartilhado.processar(base.registros(), inicio, fim); // <- estado compartilhado!
                long fimNs = System.nanoTime();
                return new Parcial(null, new FatiaExecutada(indice, nomeThread(Thread.currentThread()), false,
                        inicio, fim, ms(ini - t0), ms(fimNs - t0)));
            });
        }
        List<Parcial> parciais = executarTodas(pool(p), tarefas);
        long t1 = System.nanoTime();
        ResultadoDemanda resultado = AnaliseDemanda.analisar(compartilhado, base.estoqueAtual());
        long t2 = System.nanoTime();
        return new Execucao("inseguro", p, n, ms(t2 - t0), ms(t1 - t0), 0, ms(t2 - t1),
                parciais.stream().map(Parcial::fatia).toList(), resultado);
    }

    // ------------------------------------------------------------------ infraestrutura

    private record Parcial(Acumulador acumulador, FatiaExecutada fatia) { }

    private static List<Parcial> executarTodas(ExecutorService executor, List<Callable<Parcial>> tarefas) {
        try {
            List<Future<Parcial>> futuros = executor.invokeAll(tarefas); // bloqueia até todas terminarem
            List<Parcial> resultado = new ArrayList<>(futuros.size());
            for (Future<Parcial> f : futuros) resultado.add(f.get());
            return resultado;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Processamento interrompido", e);
        } catch (ExecutionException e) {
            throw new IllegalStateException("Falha em uma das threads", e.getCause());
        }
    }

    private ExecutorService pool(int threads) {
        validarThreads(threads);
        return pools.computeIfAbsent(threads, qtd -> {
            AtomicInteger contador = new AtomicInteger(1);
            ThreadPoolExecutor executor = new ThreadPoolExecutor(qtd, qtd, 0L, TimeUnit.MILLISECONDS,
                    new LinkedBlockingQueue<>(), r -> {
                Thread t = new Thread(r, "hemo-p" + qtd + "-worker-" + contador.getAndIncrement());
                t.setDaemon(true);
                return t;
            });
            executor.prestartAllCoreThreads(); // threads já criadas: não medimos o custo de criação
            return executor;
        });
    }

    private static String nomeThread(Thread t) {
        return t.getName().isEmpty() ? t.toString() : t.getName();
    }

    private static void validarThreads(int p) {
        if (p < 1 || p > 64) throw new IllegalArgumentException("threads deve estar entre 1 e 64");
    }

    private static double ms(long nanos) {
        return Math.round(nanos / 1_000.0) / 1_000.0;
    }

    @Override
    public void close() {
        pools.values().forEach(ExecutorService::shutdownNow);
        pools.clear();
    }
}
