package br.com.hemotrack.service;

import br.com.hemotrack.core.BaseHistorica;
import br.com.hemotrack.core.Execucao;
import br.com.hemotrack.core.GeradorDados;
import br.com.hemotrack.core.ProcessadorDemanda;
import jakarta.annotation.PreDestroy;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Camada de aplicação da US07.
 *
 * A base histórica fica em memória para isolar o que a atividade quer medir:
 * o PROCESSAMENTO. Em produção ela viria do banco uma única vez (ou de um cache)
 * e o custo dominante, na escala nacional, é o cálculo sobre os milhões de registros.
 */
@Service
public class DemandaService {

    public enum Modo { SEQUENCIAL, PLATAFORMA, VIRTUAL, INSEGURO }

    private final ProcessadorDemanda processador = new ProcessadorDemanda();
    private final AtomicReference<BaseHistorica> base = new AtomicReference<>();

    public synchronized Map<String, Object> gerarBase(int tamanho, long semente) {
        if (tamanho < 1_000 || tamanho > 20_000_000) {
            throw new IllegalArgumentException("tamanho deve estar entre 1.000 e 20.000.000");
        }
        base.set(null);
        System.gc(); // libera a base anterior antes de alocar a nova (evita medir coleta de lixo depois)
        base.set(GeradorDados.gerar(tamanho, semente));
        return infoBase();
    }

    public Map<String, Object> infoBase() {
        BaseHistorica b = base.get();
        Map<String, Object> info = new LinkedHashMap<>();
        info.put("carregada", b != null);
        if (b != null) {
            info.put("tamanho", b.tamanho());
            info.put("semente", b.semente());
            info.put("inicioHistorico", b.inicio().toString());
            info.put("semanas", b.semanas());
            info.put("tempoGeracaoMs", Math.round(b.tempoGeracaoMs()));
        }
        return info;
    }

    public Execucao executar(Modo modo, int threads) {
        BaseHistorica b = base.get();
        if (b == null) throw new IllegalStateException("Nenhuma base carregada. Gere os dados em POST /api/dados.");
        return switch (modo) {
            case SEQUENCIAL -> processador.sequencial(b);
            case PLATAFORMA -> processador.plataforma(b, threads);
            case VIRTUAL -> processador.virtual(b, threads);
            case INSEGURO -> processador.inseguro(b, threads);
        };
    }

    @PreDestroy
    public void encerrar() {
        processador.close();
    }
}
