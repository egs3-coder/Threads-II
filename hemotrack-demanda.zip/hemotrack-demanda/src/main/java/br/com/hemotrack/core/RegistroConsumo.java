package br.com.hemotrack.core;

/**
 * Uma requisição histórica de hemocomponente (US01) já encerrada.
 *
 * @param id              identificador de rastreamento
 * @param hospitalId      hospital requisitante
 * @param fuso            índice do fuso horário do hospital em {@link FusosBrasil#ZONAS}
 * @param tipo            tipo sanguíneo do paciente
 * @param instanteUtcMs   momento da requisição em UTC (epoch millis), como fica gravado no banco
 * @param bolsas          quantidade de bolsas requisitadas
 * @param atendida        false se a requisição foi cancelada (não conta como consumo)
 */
public record RegistroConsumo(long id, int hospitalId, byte fuso, TipoSanguineo tipo,
                              long instanteUtcMs, int bolsas, boolean atendida) {
}
