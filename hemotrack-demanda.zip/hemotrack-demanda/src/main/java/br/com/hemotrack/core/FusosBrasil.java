package br.com.hemotrack.core;

import java.time.ZoneId;

/** Os quatro fusos horários do Brasil. Cada hospital pertence a um deles. */
public final class FusosBrasil {
    public static final ZoneId[] ZONAS = {
            ZoneId.of("America/Noronha"),    // UTC-2
            ZoneId.of("America/Recife"),     // UTC-3 (Brasília)
            ZoneId.of("America/Manaus"),     // UTC-4
            ZoneId.of("America/Rio_Branco")  // UTC-5
    };
    /** Participação aproximada dos hospitais em cada fuso. */
    static final double[] PESO = {0.001, 0.80, 0.16, 0.039};

    private FusosBrasil() { }
}
