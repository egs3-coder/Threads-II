package br.com.hemotrack.core;

import java.util.List;

/**
 * Resultado + métricas de uma execução.
 * tempoProcessamentoMs = divisão + processamento das fatias + agregação + análise.
 */
public record Execucao(String modo,
                       int threads,
                       int tamanho,
                       double tempoProcessamentoMs,
                       double tempoFatiasMs,
                       double tempoAgregacaoMs,
                       double tempoAnaliseMs,
                       List<FatiaExecutada> fatias,
                       ResultadoDemanda resultado) {
}
