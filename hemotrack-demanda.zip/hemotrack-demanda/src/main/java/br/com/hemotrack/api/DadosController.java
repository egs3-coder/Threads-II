package br.com.hemotrack.api;

import br.com.hemotrack.service.DemandaService;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class DadosController {

    private final DemandaService service;

    public DadosController(DemandaService service) {
        this.service = service;
    }

    /** Gera o histórico sintético. Ex.: POST /api/dados?tamanho=1000000&semente=42 */
    @PostMapping("/dados")
    public Map<String, Object> gerar(@RequestParam(defaultValue = "1000000") int tamanho,
                                     @RequestParam(defaultValue = "42") long semente) {
        return service.gerarBase(tamanho, semente);
    }

    @GetMapping("/dados")
    public Map<String, Object> info() {
        return service.infoBase();
    }

    /** Dados da máquina de teste - vão para o relatório junto com as medições. */
    @GetMapping("/sistema")
    public Map<String, Object> sistema() {
        Runtime rt = Runtime.getRuntime();
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("nucleosDisponiveis", rt.availableProcessors());
        m.put("javaVersao", System.getProperty("java.version"));
        m.put("jvm", System.getProperty("java.vm.name"));
        m.put("so", System.getProperty("os.name") + " " + System.getProperty("os.arch"));
        m.put("heapMaximoMb", rt.maxMemory() / (1024 * 1024));
        return m;
    }
}
