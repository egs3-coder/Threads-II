package br.com.hemotrack.core;

/** Linha do tempo de uma thread: qual fatia ela processou e quando (ms desde o início da requisição). */
public record FatiaExecutada(int indice,
                             String thread,
                             boolean virtual,
                             int inicioIndice,
                             int fimIndice,
                             double inicioMs,
                             double fimMs) {
}
