package br.com.hemotrack.core;

/**
 * Os 8 tipos ABO/Rh. A prevalência aproxima a distribuição da população brasileira
 * e é usada apenas pelo gerador de dados sintéticos.
 */
public enum TipoSanguineo {
    A_POS("A+", 0.340),
    A_NEG("A-", 0.080),
    B_POS("B+", 0.080),
    B_NEG("B-", 0.020),
    AB_POS("AB+", 0.025),
    AB_NEG("AB-", 0.005),
    O_POS("O+", 0.360),
    O_NEG("O-", 0.090);

    public static final TipoSanguineo[] TODOS = values();
    public static final int QUANTIDADE = TODOS.length;

    private final String rotulo;
    private final double prevalencia;

    TipoSanguineo(String rotulo, double prevalencia) {
        this.rotulo = rotulo;
        this.prevalencia = prevalencia;
    }

    public String rotulo() { return rotulo; }
    public double prevalencia() { return prevalencia; }
}
