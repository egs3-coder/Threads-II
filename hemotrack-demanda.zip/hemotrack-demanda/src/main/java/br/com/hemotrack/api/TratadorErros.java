package br.com.hemotrack.api;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Map;

@RestControllerAdvice
public class TratadorErros {

    @ExceptionHandler(IllegalStateException.class)
    public ResponseEntity<Map<String, String>> semBase(IllegalStateException e) {
        return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("erro", e.getMessage()));
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, String>> invalido(IllegalArgumentException e) {
        String msg = e.getMessage() != null && e.getMessage().startsWith("No enum constant")
                ? "modo inválido: use sequencial, plataforma, virtual ou inseguro"
                : e.getMessage();
        return ResponseEntity.badRequest().body(Map.of("erro", msg));
    }

    @ExceptionHandler(OutOfMemoryError.class)
    public ResponseEntity<Map<String, String>> semMemoria(OutOfMemoryError e) {
        return ResponseEntity.status(HttpStatus.INSUFFICIENT_STORAGE)
                .body(Map.of("erro", "Memória insuficiente para essa base. Rode com -Xmx3g ou use um tamanho menor."));
    }
}
