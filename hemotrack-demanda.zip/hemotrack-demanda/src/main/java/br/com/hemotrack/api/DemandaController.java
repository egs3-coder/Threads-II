package br.com.hemotrack.api;

import br.com.hemotrack.core.Execucao;
import br.com.hemotrack.service.DemandaService;
import br.com.hemotrack.service.DemandaService.Modo;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * US07 - Análise Preditiva de Demanda por Tipo Sanguíneo.
 *
 * GET /api/demanda/preditiva?modo=sequencial
 * GET /api/demanda/preditiva?modo=plataforma&threads=4
 * GET /api/demanda/preditiva?modo=virtual&threads=8
 * GET /api/demanda/preditiva?modo=inseguro&threads=8   (demonstração de race condition)
 */
@RestController
@RequestMapping("/api/demanda")
public class DemandaController {

    private final DemandaService service;

    public DemandaController(DemandaService service) {
        this.service = service;
    }

    @GetMapping("/preditiva")
    public Execucao preditiva(@RequestParam(defaultValue = "sequencial") String modo,
                              @RequestParam(defaultValue = "1") int threads) {
        return service.executar(Modo.valueOf(modo.toUpperCase()), threads);
    }

    /** Roda todas as versões e compara as assinaturas: iguais = sem race condition. */
    @GetMapping("/verificar")
    public Map<String, Object> verificar(@RequestParam(defaultValue = "8") int threads) {
        String referencia = service.executar(Modo.SEQUENCIAL, 1).resultado().assinatura();
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("sequencial", referencia);
        boolean todasIguais = true;
        for (int t : new int[]{2, 4, threads}) {
            String p = service.executar(Modo.PLATAFORMA, t).resultado().assinatura();
            String v = service.executar(Modo.VIRTUAL, t).resultado().assinatura();
            r.put("plataforma_" + t, p);
            r.put("virtual_" + t, v);
            todasIguais &= referencia.equals(p) && referencia.equals(v);
        }
        r.put("todasIguais", todasIguais);
        return r;
    }
}
