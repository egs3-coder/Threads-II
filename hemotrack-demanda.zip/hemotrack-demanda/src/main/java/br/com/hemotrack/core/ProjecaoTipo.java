package br.com.hemotrack.core;

/** Uma linha da tela de "Demanda Preditiva" (US07). */
public record ProjecaoTipo(String tipo,
                           long totalHistorico,
                           double mediaSemanal,        // μ
                           double desvioSemanal,       // σ
                           double tendenciaSemanal,    // inclinação da regressão linear (bolsas/semana)
                           double demandaTrimestre,    // projeção para as próximas 13 semanas
                           double desvioTrimestre,     // σ·√13
                           long estoqueAtual,
                           double probabilidadeRuptura,
                           String risco) {
}
