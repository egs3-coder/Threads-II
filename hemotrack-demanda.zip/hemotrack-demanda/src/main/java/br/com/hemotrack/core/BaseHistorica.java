package br.com.hemotrack.core;

import java.time.LocalDate;
import java.util.List;

/**
 * Histórico de consumo já carregado na camada de aplicação, mais o estoque atual por tipo.
 * A lista é imutável e compartilhada entre as threads apenas para LEITURA,
 * por isso não precisa de sincronização.
 */
public record BaseHistorica(List<RegistroConsumo> registros,
                            LocalDate inicio,
                            int semanas,
                            long[] estoqueAtual,
                            long semente,
                            double tempoGeracaoMs) {

    public int tamanho() { return registros.size(); }
}
