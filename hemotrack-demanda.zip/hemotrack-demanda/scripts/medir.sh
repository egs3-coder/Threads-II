#!/usr/bin/env bash
# Mede o TEMPO DE RESPOSTA DO ENDPOINT com curl (alternativa à bateria da página).
# Uso: ./scripts/medir.sh [repeticoes]      (com a aplicação rodando em localhost:8080)
# Saída: medicoes.csv
set -euo pipefail
URL=${URL:-http://localhost:8080}
R=${1:-10}
TAMANHOS=${TAMANHOS:-"100000 1000000 5000000"}
VERSOES="sequencial:1 plataforma:2 plataforma:4 plataforma:8 virtual:2 virtual:4 virtual:8"
SAIDA=medicoes.csv

mediana() { sort -n | awk '{a[NR]=$1} END {print (NR%2 ? a[(NR+1)/2] : (a[NR/2]+a[NR/2+1])/2)}'; }

echo "registros;versao;threads;resposta_mediana_ms;speedup" > "$SAIDA"
for n in $TAMANHOS; do
  echo "== Gerando base com $n registros"
  curl -s -X POST "$URL/api/dados?tamanho=$n&semente=42" > /dev/null
  echo "   aquecendo o JIT..."
  for i in 1 2 3 4 5; do for v in $VERSOES; do
    curl -s -o /dev/null "$URL/api/demanda/preditiva?modo=${v%%:*}&threads=${v##*:}"; done; done
  seq_ms=""
  for v in $VERSOES; do
    modo=${v%%:*}; t=${v##*:}
    med=$(for i in $(seq "$R"); do
            curl -s -o /dev/null -w "%{time_total}\n" "$URL/api/demanda/preditiva?modo=$modo&threads=$t"
          done | awk '{printf "%.3f\n", $1*1000}' | mediana)
    [ "$modo" = "sequencial" ] && seq_ms=$med
    sp=$(awk -v a="$seq_ms" -v b="$med" 'BEGIN{printf "%.2f", a/b}')
    printf "   %-10s %d thread(s): %8.2f ms  speedup %sx\n" "$modo" "$t" "$med" "$sp"
    echo "$n;$modo;$t;$med;$sp" >> "$SAIDA"
  done
done
echo "Verificação de resultados idênticos:"
curl -s "$URL/api/demanda/verificar?threads=8"; echo
echo "Resultados em $SAIDA"
