# HemoTrack | US07 Demanda preditiva com threads

Serviço Spring Boot que implementa a **US07 (Análise Preditiva de Demanda por Tipo Sanguíneo)** em quatro versões,
todas no mesmo endpoint e devolvendo **exatamente a mesma resposta**:

| `modo` | O que é |
|---|---|
| `sequencial` | uma thread percorre todo o histórico |
| `plataforma` | `ExecutorService` com 2, 4 ou 8 threads; cada uma processa a própria fatia com acumulador local; soma no final |
| `virtual` | o mesmo, com threads virtuais do Java 21 (opcional da atividade) |
| `inseguro` | versão **errada de propósito**: threads somando no mesmo acumulador sem sincronização (demonstra race condition) |

## Como rodar

Pré-requisitos: **JDK 21** e **Maven 3.9+** (ou abra o projeto no IntelliJ / VS Code e rode `HemotrackApplication`).

```bash
mvn spring-boot:run          # já sobe com -Xmx3g (configurado no pom.xml)
```

Abra **http://localhost:8080**. A página tem:

1. **Base histórica**: gera 100 mil, 1, 5 ou 10 milhões de requisições sintéticas (semente fixa = dados reprodutíveis).
2. **Comparar**: roda sequencial e paralelo e mostra a linha do tempo de cada thread (qual fatia processou, quando começou e terminou), o speedup e a assinatura SHA-256 das duas respostas.
3. **Bateria de medições**: mede o tempo de resposta do endpoint (mediana de N repetições, com aquecimento do JIT) para todas as versões e tamanhos; gera a tabela, os gráficos e o CSV/Markdown para o relatório.
4. **Race condition**: roda a versão sem proteção 5 vezes e mostra as bolsas "perdidas".

Rodando pelo IntelliJ, adicione `-Xmx3g` em *VM options* se for usar 5 ou 10 milhões de registros.

## Endpoints

```bash
curl -X POST "localhost:8080/api/dados?tamanho=1000000&semente=42"       # gera a base
curl "localhost:8080/api/demanda/preditiva?modo=sequencial"
curl "localhost:8080/api/demanda/preditiva?modo=plataforma&threads=4"
curl "localhost:8080/api/demanda/preditiva?modo=virtual&threads=8"
curl "localhost:8080/api/demanda/preditiva?modo=inseguro&threads=8"      # race condition
curl "localhost:8080/api/demanda/verificar?threads=8"                    # compara todas as assinaturas
curl "localhost:8080/api/sistema"                                        # núcleos, Java, heap
```

Medição pelo terminal (Linux, macOS ou Git Bash): `./scripts/medir.sh 10` gera `medicoes.csv`.

Testes (sequencial = paralelo para 2, 3, 4, 7, 8, 16 threads e virtuais): `mvn test`

## Estrutura

```
src/main/java/br/com/hemotrack/
├── core/                       ← algoritmo em Java puro (sem Spring, testável isolado)
│   ├── ProcessadorDemanda      ← versões sequencial, plataforma, virtual e insegura
│   ├── Acumulador              ← laço quente O(n) + soma dos parciais + assinatura SHA-256
│   ├── AnaliseDemanda          ← μ, σ, tendência, projeção trimestral, P(ruptura)
│   ├── GeradorDados            ← histórico sintético (104 semanas, 5.000 hospitais, 4 fusos)
│   └── records: RegistroConsumo, BaseHistorica, Execucao, FatiaExecutada, ResultadoDemanda, ProjecaoTipo
├── service/DemandaService      ← mantém a base em memória e escolhe a versão
└── api/                        ← DemandaController, DadosController, TratadorErros
src/main/resources/static/index.html   ← página de demonstração
docs/1-JUSTIFICATIVA.md         ← escolha da operação, Big-O, gargalo, particionamento
docs/2-ANALISE.md               ← modelo da tabela + análise (preencher com os números de vocês)
```

## Dicas para medições confiáveis

- Notebook **na tomada**, outros programas fechados, e rodem cada bateria duas vezes para ver se os números se repetem.
- Use a **mediana** (a página já faz isso): picos do GC ou do sistema operacional distorcem a média.
- Não compare a primeira execução: o JIT ainda está compilando o código (a página faz aquecimento antes de medir).
- Se o processador tiver menos de 8 núcleos, o speedup de 8 threads vai estacionar. Isso é esperado e é argumento na análise.
