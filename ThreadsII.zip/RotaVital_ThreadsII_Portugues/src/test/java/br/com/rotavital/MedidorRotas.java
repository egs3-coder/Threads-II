package br.com.rotavital;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Arrays;
import java.util.Locale;

/**
 * Mede o tempo de resposta dos endpoints reais da aplicação.
 * Também confirma que todas as versões devolvem exatamente o mesmo resultado.
 */
public class MedidorRotas {

    private static final String ENDERECO_BASE = "http://localhost:8080/api/validacoes";
    private static final int REPETICOES = 9;

    public static void main(String[] argumentos) throws Exception {
        HttpClient clienteHttp = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(10))
                .build();

        int[] quantidades = {100_000, 1_000_000};
        int[] numerosThreads = {2, 4, 8, 16};

        System.out.println("quantidade,modo,numero_threads,tempo_resposta_ms,ganho");

        for (int quantidade : quantidades) {
            String rotaSequencial = ENDERECO_BASE + "/sequencial?quantidade=" + quantidade;
            String respostaReferencia = executar(clienteHttp, rotaSequencial).body();

            // Duas execuções de aquecimento antes da medição.
            executar(clienteHttp, rotaSequencial);
            executar(clienteHttp, rotaSequencial);

            double tempoSequencial = medirMediana(clienteHttp, rotaSequencial, respostaReferencia);
            imprimir(quantidade, "sequencial", 1, tempoSequencial, 1.0);

            for (int numeroThreads : numerosThreads) {
                String rotaParalela = ENDERECO_BASE
                        + "/paralelo?quantidade=" + quantidade
                        + "&numeroThreads=" + numeroThreads;

                executar(clienteHttp, rotaParalela);
                double tempoParalelo = medirMediana(clienteHttp, rotaParalela, respostaReferencia);
                imprimir(quantidade, "threads_plataforma", numeroThreads, tempoParalelo,
                        tempoSequencial / tempoParalelo);
            }

            String rotaVirtual = ENDERECO_BASE
                    + "/virtuais?quantidade=" + quantidade
                    + "&numeroTarefas=8";

            executar(clienteHttp, rotaVirtual);
            double tempoVirtual = medirMediana(clienteHttp, rotaVirtual, respostaReferencia);
            imprimir(quantidade, "threads_virtuais", 8, tempoVirtual,
                    tempoSequencial / tempoVirtual);
        }
    }

    private static double medirMediana(
            HttpClient clienteHttp,
            String rota,
            String respostaEsperada
    ) throws Exception {
        double[] tempos = new double[REPETICOES];

        for (int repeticao = 0; repeticao < REPETICOES; repeticao++) {
            long inicio = System.nanoTime();
            HttpResponse<String> resposta = executar(clienteHttp, rota);
            tempos[repeticao] = (System.nanoTime() - inicio) / 1_000_000.0;

            if (!respostaEsperada.equals(resposta.body())) {
                throw new IllegalStateException("As versões produziram resultados diferentes.");
            }
        }

        Arrays.sort(tempos);
        return tempos[tempos.length / 2];
    }

    private static HttpResponse<String> executar(HttpClient clienteHttp, String rota) throws Exception {
        HttpRequest requisicaoHttp = HttpRequest.newBuilder()
                .uri(URI.create(rota))
                .timeout(Duration.ofSeconds(60))
                .GET()
                .build();

        HttpResponse<String> resposta = clienteHttp.send(
                requisicaoHttp,
                HttpResponse.BodyHandlers.ofString()
        );

        if (resposta.statusCode() != 200) {
            throw new IllegalStateException(
                    "A rota respondeu HTTP " + resposta.statusCode() + ": " + resposta.body()
            );
        }

        return resposta;
    }

    private static void imprimir(
            int quantidade,
            String modo,
            int numeroThreads,
            double tempo,
            double ganho
    ) {
        System.out.printf(
                Locale.US,
                "%d,%s,%d,%.3f,%.3f%n",
                quantidade,
                modo,
                numeroThreads,
                tempo,
                ganho
        );
    }
}
