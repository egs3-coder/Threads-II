package br.com.rotavital;

import br.com.rotavital.modelo.Requisicao;
import br.com.rotavital.modelo.ResultadoValidacao;
import br.com.rotavital.servico.GeradorRequisicoes;
import br.com.rotavital.servico.ServicoValidacaoRequisicoes;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

/** Confirma automaticamente que as três versões geram a mesma resposta. */
class TesteConsistenciaResultados {

    @Test
    void todasAsVersoesDevemProduzirOMesmoResultado() {
        GeradorRequisicoes gerador = new GeradorRequisicoes();
        ServicoValidacaoRequisicoes servico = new ServicoValidacaoRequisicoes();
        Requisicao[] requisicoes = gerador.obter(100_000);

        ResultadoValidacao sequencial = servico.validarSequencial(requisicoes);
        ResultadoValidacao plataforma = servico.validarComThreadsDePlataforma(requisicoes, 4);
        ResultadoValidacao virtuais = servico.validarComThreadsVirtuais(requisicoes, 8);

        assertEquals(sequencial, plataforma);
        assertEquals(sequencial, virtuais);
    }
}
