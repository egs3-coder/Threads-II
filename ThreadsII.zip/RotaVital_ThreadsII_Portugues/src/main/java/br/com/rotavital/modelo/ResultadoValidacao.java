package br.com.rotavital.modelo;

/**
 * Resume o resultado final da validação.
 * As três versões devem produzir exatamente estes mesmos valores.
 */
public record ResultadoValidacao(
        int totalProcessado,
        int requisicoesValidas,
        int requisicoesInvalidas,
        int requisicoesUrgentes,
        long somaQuantidadesValidas,
        long assinaturaDoResultado
) {
}
