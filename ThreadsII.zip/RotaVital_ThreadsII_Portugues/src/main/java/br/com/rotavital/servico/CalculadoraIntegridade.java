package br.com.rotavital.servico;

import br.com.rotavital.modelo.Requisicao;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Calcula um código de integridade com SHA-256.
 * Esse cálculo consome CPU e, por isso, é adequado para demonstrar ganho com paralelismo.
 */
public final class CalculadoraIntegridade {

    private CalculadoraIntegridade() {
        // Impede a criação de objetos desta classe utilitária.
    }

    public static MessageDigest criarCalculadora() {
        try {
            return MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException excecao) {
            throw new IllegalStateException("O algoritmo SHA-256 não está disponível.", excecao);
        }
    }

    public static long calcular(MessageDigest calculadora, Requisicao requisicao, byte[] saida) {
        calculadora.reset();

        adicionarLong(calculadora, requisicao.identificador());
        adicionarInteiro(calculadora, requisicao.hospital());
        adicionarInteiro(calculadora, requisicao.item());
        adicionarInteiro(calculadora, requisicao.quantidade());
        adicionarInteiro(calculadora, requisicao.prioridade());
        adicionarLong(calculadora, requisicao.instanteCriacao());

        try {
            calculadora.digest(saida, 0, saida.length);
        } catch (java.security.DigestException excecao) {
            throw new IllegalStateException("Falha ao calcular o código de integridade.", excecao);
        }

        // Usa os oito primeiros bytes do SHA-256 para formar um número long.
        return ((long) (saida[0] & 0xff) << 56)
                | ((long) (saida[1] & 0xff) << 48)
                | ((long) (saida[2] & 0xff) << 40)
                | ((long) (saida[3] & 0xff) << 32)
                | ((long) (saida[4] & 0xff) << 24)
                | ((long) (saida[5] & 0xff) << 16)
                | ((long) (saida[6] & 0xff) << 8)
                | ((long) (saida[7] & 0xff));
    }

    private static void adicionarInteiro(MessageDigest calculadora, int valor) {
        calculadora.update((byte) (valor >>> 24));
        calculadora.update((byte) (valor >>> 16));
        calculadora.update((byte) (valor >>> 8));
        calculadora.update((byte) valor);
    }

    private static void adicionarLong(MessageDigest calculadora, long valor) {
        calculadora.update((byte) (valor >>> 56));
        calculadora.update((byte) (valor >>> 48));
        calculadora.update((byte) (valor >>> 40));
        calculadora.update((byte) (valor >>> 32));
        calculadora.update((byte) (valor >>> 24));
        calculadora.update((byte) (valor >>> 16));
        calculadora.update((byte) (valor >>> 8));
        calculadora.update((byte) valor);
    }
}
