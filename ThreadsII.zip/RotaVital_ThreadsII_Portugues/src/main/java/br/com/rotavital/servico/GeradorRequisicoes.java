package br.com.rotavital.servico;

import br.com.rotavital.modelo.Requisicao;
import org.springframework.stereotype.Component;

import java.security.MessageDigest;
import java.util.SplittableRandom;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Gera dados fictícios para os testes.
 * A mesma quantidade sempre gera os mesmos dados, garantindo uma comparação justa.
 */
@Component
public class GeradorRequisicoes {

    private static final long SEMENTE = 20260911L;

    // Guarda os dados já gerados para que o tempo de geração não entre na medição do processamento.
    private final ConcurrentHashMap<Integer, Requisicao[]> memoriaRequisicoes = new ConcurrentHashMap<>();

    public Requisicao[] obter(int quantidade) {
        if (quantidade < 1 || quantidade > 2_000_000) {
            throw new IllegalArgumentException("A quantidade deve estar entre 1 e 2.000.000.");
        }

        return memoriaRequisicoes.computeIfAbsent(quantidade, this::gerar);
    }

    private Requisicao[] gerar(int quantidade) {
        SplittableRandom aleatorio = new SplittableRandom(SEMENTE + quantidade);
        Requisicao[] requisicoes = new Requisicao[quantidade];
        MessageDigest calculadora = CalculadoraIntegridade.criarCalculadora();
        byte[] saida = new byte[32];

        for (int indice = 0; indice < quantidade; indice++) {
            long identificador = indice + 1L;
            int hospital = aleatorio.nextInt(1, 5_001);
            int item = aleatorio.nextInt(1, 20_001);
            int quantidadeSolicitada = aleatorio.nextInt(1, 501);
            int prioridade = aleatorio.nextInt(1, 6);
            long instanteCriacao = 1_780_000_000_000L + aleatorio.nextLong(0, 86_400_000L * 30L);

            Requisicao requisicaoSemCodigo = new Requisicao(
                    identificador,
                    hospital,
                    item,
                    quantidadeSolicitada,
                    prioridade,
                    instanteCriacao,
                    0L
            );

            long codigoIntegridade = CalculadoraIntegridade.calcular(calculadora, requisicaoSemCodigo, saida);

            // Aproximadamente 1% dos registros ficam inválidos de propósito.
            if (indice % 100 == 0) {
                codigoIntegridade ^= 0x5A5A5A5A5A5A5A5AL;
            }

            requisicoes[indice] = new Requisicao(
                    identificador,
                    hospital,
                    item,
                    quantidadeSolicitada,
                    prioridade,
                    instanteCriacao,
                    codigoIntegridade
            );
        }

        return requisicoes;
    }
}
