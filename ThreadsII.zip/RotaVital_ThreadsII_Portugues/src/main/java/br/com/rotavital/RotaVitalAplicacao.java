package br.com.rotavital;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Classe principal do projeto.
 * Inicia o Spring Boot e disponibiliza a API e a página visual.
 */
@SpringBootApplication
public class RotaVitalAplicacao {

    public static void main(String[] argumentos) {
        SpringApplication.run(RotaVitalAplicacao.class, argumentos);
    }
}
