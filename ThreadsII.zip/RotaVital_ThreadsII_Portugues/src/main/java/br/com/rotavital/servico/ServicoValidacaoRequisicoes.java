package br.com.rotavital.servico;

import br.com.rotavital.modelo.Requisicao;
import br.com.rotavital.modelo.ResultadoValidacao;
import org.springframework.stereotype.Service;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Contém as três formas de processamento exigidas pela atividade:
 * 1) sequencial;
 * 2) threads de plataforma;
 * 3) threads virtuais do Java 21.
 */
@Service
public class ServicoValidacaoRequisicoes {

    /** Processa todos os registros em um único fluxo de execução. */
    public ResultadoValidacao validarSequencial(Requisicao[] requisicoes) {
        ResultadoParcial parcial = processarTrecho(requisicoes, 0, requisicoes.length);
        return parcial.converterParaResultado();
    }

    /** Divide os dados em partes e processa cada parte em uma thread de plataforma. */
    public ResultadoValidacao validarComThreadsDePlataforma(Requisicao[] requisicoes, int numeroThreads) {
        validarQuantidadeDeTarefas(numeroThreads);

        try (ExecutorService executador = Executors.newFixedThreadPool(numeroThreads)) {
            return processarEmParalelo(requisicoes, numeroThreads, executador);
        }
    }

    /**
     * Divide os dados em tarefas executadas por threads virtuais.
     * Threads virtuais fazem parte do Java 21.
     */
    public ResultadoValidacao validarComThreadsVirtuais(Requisicao[] requisicoes, int numeroTarefas) {
        validarQuantidadeDeTarefas(numeroTarefas);

        try (ExecutorService executador = Executors.newVirtualThreadPerTaskExecutor()) {
            return processarEmParalelo(requisicoes, numeroTarefas, executador);
        }
    }

    /** Cria as partes do trabalho, aguarda cada uma e soma os resultados no final. */
    private ResultadoValidacao processarEmParalelo(
            Requisicao[] requisicoes,
            int numeroTarefas,
            ExecutorService executador
    ) {
        int totalRegistros = requisicoes.length;
        int tamanhoTrecho = (totalRegistros + numeroTarefas - 1) / numeroTarefas;
        List<Future<ResultadoParcial>> tarefas = new ArrayList<>();

        for (int numeroTarefa = 0; numeroTarefa < numeroTarefas; numeroTarefa++) {
            int inicio = numeroTarefa * tamanhoTrecho;
            int fim = Math.min(inicio + tamanhoTrecho, totalRegistros);

            if (inicio >= fim) {
                break;
            }

            tarefas.add(executador.submit(() -> processarTrecho(requisicoes, inicio, fim)));
        }

        ResultadoParcial resultadoFinal = new ResultadoParcial();

        for (Future<ResultadoParcial> tarefa : tarefas) {
            try {
                resultadoFinal.somar(tarefa.get());
            } catch (InterruptedException excecao) {
                Thread.currentThread().interrupt();
                throw new IllegalStateException("A validação foi interrompida.", excecao);
            } catch (ExecutionException excecao) {
                throw new IllegalStateException("Uma tarefa de validação falhou.", excecao.getCause());
            }
        }

        return resultadoFinal.converterParaResultado();
    }

    /** Valida um intervalo independente do vetor. Essa é a parte que pode rodar em paralelo. */
    private ResultadoParcial processarTrecho(Requisicao[] requisicoes, int inicio, int fim) {
        MessageDigest calculadora = CalculadoraIntegridade.criarCalculadora();
        byte[] saida = new byte[32];
        ResultadoParcial resultado = new ResultadoParcial();

        for (int indice = inicio; indice < fim; indice++) {
            Requisicao requisicao = requisicoes[indice];
            long codigoCalculado = CalculadoraIntegridade.calcular(calculadora, requisicao, saida);

            boolean camposValidos = requisicao.hospital() >= 1
                    && requisicao.hospital() <= 5_000
                    && requisicao.item() >= 1
                    && requisicao.item() <= 20_000
                    && requisicao.quantidade() >= 1
                    && requisicao.quantidade() <= 500
                    && requisicao.prioridade() >= 1
                    && requisicao.prioridade() <= 5;

            boolean integridadeValida = codigoCalculado == requisicao.codigoIntegridade();
            boolean requisicaoValida = camposValidos && integridadeValida;

            resultado.totalProcessado++;
            resultado.assinaturaDoResultado ^= codigoCalculado;

            if (requisicaoValida) {
                resultado.requisicoesValidas++;
                resultado.somaQuantidadesValidas += requisicao.quantidade();

                if (requisicao.prioridade() >= 4) {
                    resultado.requisicoesUrgentes++;
                }
            } else {
                resultado.requisicoesInvalidas++;
            }
        }

        return resultado;
    }

    private void validarQuantidadeDeTarefas(int quantidade) {
        if (quantidade < 1 || quantidade > 64) {
            throw new IllegalArgumentException("O número de threads ou tarefas deve estar entre 1 e 64.");
        }
    }

    /** Resultado interno de cada parte. Só é combinado depois que as tarefas terminam. */
    private static class ResultadoParcial {
        private int totalProcessado;
        private int requisicoesValidas;
        private int requisicoesInvalidas;
        private int requisicoesUrgentes;
        private long somaQuantidadesValidas;
        private long assinaturaDoResultado;

        private void somar(ResultadoParcial outroResultado) {
            totalProcessado += outroResultado.totalProcessado;
            requisicoesValidas += outroResultado.requisicoesValidas;
            requisicoesInvalidas += outroResultado.requisicoesInvalidas;
            requisicoesUrgentes += outroResultado.requisicoesUrgentes;
            somaQuantidadesValidas += outroResultado.somaQuantidadesValidas;
            assinaturaDoResultado ^= outroResultado.assinaturaDoResultado;
        }

        private ResultadoValidacao converterParaResultado() {
            return new ResultadoValidacao(
                    totalProcessado,
                    requisicoesValidas,
                    requisicoesInvalidas,
                    requisicoesUrgentes,
                    somaQuantidadesValidas,
                    assinaturaDoResultado
            );
        }
    }
}
