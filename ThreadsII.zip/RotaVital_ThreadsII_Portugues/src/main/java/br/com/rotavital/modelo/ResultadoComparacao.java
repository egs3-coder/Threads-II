package br.com.rotavital.modelo;

/**
 * Resposta agregada do endpoint de comparação.
 * Reúne as três medições executadas no backend para que a interface
 * consiga montar o gráfico com dados reais da execução atual.
 */
public record ResultadoComparacao(
        int quantidade,
        Medicao sequencial,
        Medicao plataforma,
        Medicao virtuais,
        boolean resultadosConsistentes
) {

    /** Uma medição individual do benchmark. */
    public record Medicao(
            String modo,
            int numeroThreadsOuTarefas,
            double tempoMs,
            double speedup,
            ResultadoValidacao resultado
    ) {
    }
}
