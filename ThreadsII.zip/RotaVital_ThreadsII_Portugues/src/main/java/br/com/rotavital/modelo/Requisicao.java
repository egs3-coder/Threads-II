package br.com.rotavital.modelo;

/**
 * Representa uma requisição do Rota Vital.
 * Cada objeto contém os dados que serão validados pelo processamento.
 */
public record Requisicao(
        long identificador,
        int hospital,
        int item,
        int quantidade,
        int prioridade,
        long instanteCriacao,
        long codigoIntegridade
) {
}
