package br.com.rotavital.controle;

import br.com.rotavital.modelo.Requisicao;
import br.com.rotavital.modelo.ResultadoComparacao;
import br.com.rotavital.modelo.ResultadoValidacao;
import br.com.rotavital.servico.GeradorRequisicoes;
import br.com.rotavital.servico.ServicoValidacaoRequisicoes;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.function.Supplier;

/**
 * Recebe as chamadas HTTP da página visual.
 * Cada rota executa uma versão diferente do mesmo processamento.
 */
@RestController
@RequestMapping("/api/validacoes")
public class ControladorValidacao {

    private final GeradorRequisicoes geradorRequisicoes;
    private final ServicoValidacaoRequisicoes servicoValidacao;

    public ControladorValidacao(
            GeradorRequisicoes geradorRequisicoes,
            ServicoValidacaoRequisicoes servicoValidacao
    ) {
        this.geradorRequisicoes = geradorRequisicoes;
        this.servicoValidacao = servicoValidacao;
    }

    /** Versão sequencial: um único fluxo de execução. */
    @GetMapping("/sequencial")
    public ResponseEntity<ResultadoValidacao> validarSequencial(
            @RequestParam(defaultValue = "100000") int quantidade
    ) {
        Requisicao[] requisicoes = geradorRequisicoes.obter(quantidade);

        long inicio = System.nanoTime();
        ResultadoValidacao resultado = servicoValidacao.validarSequencial(requisicoes);
        long tempoEmNanossegundos = System.nanoTime() - inicio;

        return responder(resultado, tempoEmNanossegundos);
    }

    /** Versão paralela usando threads de plataforma. */
    @GetMapping("/paralelo")
    public ResponseEntity<ResultadoValidacao> validarEmParalelo(
            @RequestParam(defaultValue = "100000") int quantidade,
            @RequestParam(defaultValue = "4") int numeroThreads
    ) {
        Requisicao[] requisicoes = geradorRequisicoes.obter(quantidade);

        long inicio = System.nanoTime();
        ResultadoValidacao resultado = servicoValidacao.validarComThreadsDePlataforma(requisicoes, numeroThreads);
        long tempoEmNanossegundos = System.nanoTime() - inicio;

        return responder(resultado, tempoEmNanossegundos);
    }

    /** Versão paralela usando threads virtuais do Java 21. */
    @GetMapping("/virtuais")
    public ResponseEntity<ResultadoValidacao> validarComThreadsVirtuais(
            @RequestParam(defaultValue = "100000") int quantidade,
            @RequestParam(defaultValue = "4") int numeroTarefas
    ) {
        Requisicao[] requisicoes = geradorRequisicoes.obter(quantidade);

        long inicio = System.nanoTime();
        ResultadoValidacao resultado = servicoValidacao.validarComThreadsVirtuais(requisicoes, numeroTarefas);
        long tempoEmNanossegundos = System.nanoTime() - inicio;

        return responder(resultado, tempoEmNanossegundos);
    }

    /**
     * Executa as três versões no servidor em uma única chamada.
     * O retorno já contém os tempos, speedups e a verificação de consistência,
     * permitindo que a página monte o gráfico sem usar valores simulados.
     */
    @GetMapping("/comparacao")
    public ResultadoComparacao comparar(
            @RequestParam(defaultValue = "100000") int quantidade,
            @RequestParam(defaultValue = "4") int numeroThreads,
            @RequestParam(defaultValue = "4") int numeroTarefas
    ) {
        Requisicao[] requisicoes = geradorRequisicoes.obter(quantidade);

        MedicaoInterna sequencial = medir(() -> servicoValidacao.validarSequencial(requisicoes));
        MedicaoInterna plataforma = medir(() -> servicoValidacao.validarComThreadsDePlataforma(requisicoes, numeroThreads));
        MedicaoInterna virtuais = medir(() -> servicoValidacao.validarComThreadsVirtuais(requisicoes, numeroTarefas));

        double speedupPlataforma = calcularSpeedup(sequencial.tempoMs(), plataforma.tempoMs());
        double speedupVirtuais = calcularSpeedup(sequencial.tempoMs(), virtuais.tempoMs());

        boolean resultadosConsistentes = sequencial.resultado().equals(plataforma.resultado())
                && sequencial.resultado().equals(virtuais.resultado());

        return new ResultadoComparacao(
                quantidade,
                new ResultadoComparacao.Medicao(
                        "Sequencial",
                        1,
                        sequencial.tempoMs(),
                        1.0,
                        sequencial.resultado()
                ),
                new ResultadoComparacao.Medicao(
                        "Threads de Plataforma",
                        numeroThreads,
                        plataforma.tempoMs(),
                        speedupPlataforma,
                        plataforma.resultado()
                ),
                new ResultadoComparacao.Medicao(
                        "Threads Virtuais",
                        numeroTarefas,
                        virtuais.tempoMs(),
                        speedupVirtuais,
                        virtuais.resultado()
                ),
                resultadosConsistentes
        );
    }

    /** Mede somente o processamento da versão recebida. */
    private MedicaoInterna medir(Supplier<ResultadoValidacao> processamento) {
        long inicio = System.nanoTime();
        ResultadoValidacao resultado = processamento.get();
        long tempoEmNanossegundos = System.nanoTime() - inicio;
        return new MedicaoInterna(resultado, tempoEmNanossegundos / 1_000_000.0);
    }

    private double calcularSpeedup(double tempoSequencial, double tempoComparado) {
        return tempoComparado > 0.0 ? tempoSequencial / tempoComparado : 0.0;
    }

    /**
     * Retorna o resultado e também informa o tempo de processamento no cabeçalho HTTP.
     * A página usa esse valor para mostrar a comparação nos testes individuais.
     */
    private ResponseEntity<ResultadoValidacao> responder(ResultadoValidacao resultado, long nanossegundos) {
        double milissegundos = nanossegundos / 1_000_000.0;

        return ResponseEntity.ok()
                .header(
                        "X-Tempo-Processamento-Ms",
                        String.format(java.util.Locale.US, "%.3f", milissegundos)
                )
                .body(resultado);
    }

    private record MedicaoInterna(ResultadoValidacao resultado, double tempoMs) {
    }
}
