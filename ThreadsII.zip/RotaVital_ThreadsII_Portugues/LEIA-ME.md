# Rota Vital - Threads II

Projeto simplificado para a atividade de **Processos e Threads**.

## O que o sistema faz

O sistema gera requisições fictícias do Rota Vital e valida cada registro. A validação verifica os campos e recalcula um código SHA-256. Como esse cálculo usa CPU e cada requisição pode ser processada de forma independente, o trabalho pode ser dividido entre várias threads.

Existem três versões:

1. **Sequencial**: usa um único fluxo de execução.
2. **Threads de plataforma**: divide os registros em partes e usa várias threads tradicionais.
3. **Threads virtuais**: usa threads virtuais do Java 21 para executar as partes.

Todas devem devolver exatamente o mesmo resultado.

## Estrutura do projeto

- `RotaVitalAplicacao.java`: inicia o Spring Boot.
- `Requisicao.java`: representa os dados de uma requisição.
- `ResultadoValidacao.java`: guarda o resumo final do processamento.
- `ResultadoComparacao.java`: reúne tempos, speedups e consistência das três versões para o gráfico dinâmico.
- `CalculadoraIntegridade.java`: calcula SHA-256 para tornar a operação CPU-bound.
- `GeradorRequisicoes.java`: cria dados determinísticos para os testes.
- `ServicoValidacaoRequisicoes.java`: contém as versões sequencial, com threads de plataforma e com threads virtuais.
- `ControladorValidacao.java`: cria os endpoints HTTP usados pela interface.
- `TratadorErros.java`: devolve mensagem amigável para entradas inválidas.
- `index.html`: página visual para executar, comparar e gerar o gráfico dinâmico com os tempos reais do backend.
- `MedidorRotas.java`: mede o tempo dos endpoints e calcula o ganho de desempenho.
- `TesteConsistenciaResultados.java`: confirma que as três versões produzem a mesma resposta.
- `medicoes.csv`: resultados de medições já realizadas.

## Como executar

Na pasta que contém o `pom.xml`, execute:

```cmd
mvn spring-boot:run
```

Depois abra no navegador:

```text
http://localhost:8080
```

## Rotas da API

Sequencial:

```text
http://localhost:8080/api/validacoes/sequencial?quantidade=100000
```

Threads de plataforma:

```text
http://localhost:8080/api/validacoes/paralelo?quantidade=100000&numeroThreads=4
```

Threads virtuais:

```text
http://localhost:8080/api/validacoes/virtuais?quantidade=100000&numeroTarefas=4
```

Comparação completa para alimentar o gráfico:

```text
http://localhost:8080/api/validacoes/comparacao?quantidade=100000&numeroThreads=4&numeroTarefas=4
```

A rota `/comparacao` executa as três versões no Spring Boot e devolve, em uma única resposta JSON, o tempo de cada versão, o speedup em relação à sequencial e a confirmação de que os resultados são consistentes. O botão **Comparar as três versões** usa essa rota e atualiza automaticamente o gráfico da interface.

## Observação sobre palavras em inglês

Os nomes criados pelo projeto foram escritos em português sempre que possível. Alguns termos não podem ser traduzidos no código porque pertencem à própria linguagem Java, ao Spring ou às APIs usadas, por exemplo: `public`, `class`, `record`, `return`, `String`, `MessageDigest`, `ExecutorService`, `Future`, `HttpClient`, `@RestController` e `@GetMapping`.

Também foi mantido o termo **thread**, porque ele é o conceito técnico pedido na própria atividade.
